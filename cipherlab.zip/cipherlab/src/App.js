import React, { useState } from "react";
import { motion } from "framer-motion";

function App() {
  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [cipher1, setCipher1] = useState("");
  const [cipher2, setCipher2] = useState("");
  const [resultCipher, setResultCipher] = useState("");
  const [result, setResult] = useState(null);

  const encrypt = (num) => {
    // Simple encryption simulation
    return btoa(num + Math.floor(Math.random() * 1000));
  };

  const decrypt = (cipher) => {
    try {
      const decoded = atob(cipher);
      return parseInt(decoded.match(/\d+/)[0]);
    } catch {
      return 0;
    }
  };

  const handleEncrypt = () => {
    const c1 = encrypt(num1);
    const c2 = encrypt(num2);
    setCipher1(c1);
    setCipher2(c2);
    setResult(null);
    setResultCipher("");
  };

  const handleCompute = (op) => {
    if (!cipher1 || !cipher2) return;
    const n1 = decrypt(cipher1);
    const n2 = decrypt(cipher2);
    let res = 0;
    if (op === "add") res = n1 + n2;
    if (op === "multiply") res = n1 * n2;
    const resCipher = encrypt(res);
    setResultCipher(resCipher);

    // Animate decryption
    setTimeout(() => {
      setResult(res);
    }, 800);
  };

  return (
    <div className="container">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        CipherLab
      </motion.h1>
      <p>Interactive Fully Homomorphic Encryption (FHE) Simulator</p>

      <motion.div
        className="card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <h2>Step 1: Input Numbers</h2>
        <input
          type="number"
          value={num1}
          onChange={(e) => setNum1(parseInt(e.target.value))}
        />
        <input
          type="number"
          value={num2}
          onChange={(e) => setNum2(parseInt(e.target.value))}
        />
        <br />
        <button onClick={handleEncrypt}>Encrypt</button>
      </motion.div>

      {cipher1 && cipher2 && (
        <motion.div
          className="card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2>Step 2: Encrypted Numbers</h2>
          <p>Encrypted Num1: {cipher1}</p>
          <p>Encrypted Num2: {cipher2}</p>
          <button onClick={() => handleCompute("add")}>Add</button>
          <button onClick={() => handleCompute("multiply")}>Multiply</button>
        </motion.div>
      )}

      {resultCipher && (
        <motion.div
          className="card"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2>Step 3: Computation Result</h2>
          <p>Encrypted Result: {resultCipher}</p>
          {result !== null && <p>Decrypted Result: {result}</p>}
        </motion.div>
      )}

      <motion.div
        className="card"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2>How It Works</h2>
        <p>
          CipherLab simulates Fully Homomorphic Encryption (FHE). Enter numbers,
          encrypt them, and perform computations on encrypted data. The result
          can be decrypted to show correctness, demonstrating how computations
          can occur without revealing raw data.
        </p>
      </motion.div>

      <div className="footer">Built by Masoom</div>
    </div>
  );
}

export default App;